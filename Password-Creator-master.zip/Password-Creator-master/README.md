This Project is made to make a password generator in python with tkinter using UI. with this application you can make passwords that are safe and easy to copy for use.
